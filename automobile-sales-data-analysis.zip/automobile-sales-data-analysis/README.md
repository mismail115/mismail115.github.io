# Automobile Sales Data Analysis & Dashboard

A portfolio-ready data analysis project that explores historical automobile sales, compares recession and non-recession periods, and presents business insights through Python visualizations and an interactive Dash dashboard.

## Project goals
- Clean and prepare automobile sales data with Pandas
- Compare sales during recession vs. non-recession periods
- Analyze vehicle-type performance
- Explore relationships among advertising spend, unemployment, consumer confidence, and sales
- Build clear visualizations with Matplotlib, Seaborn, and Plotly
- Create an interactive dashboard with Dash

## Tech stack
Python, Pandas, NumPy, Matplotlib, Seaborn, Plotly, Dash

## Dataset
This project uses the IBM Skills Network historical automobile sales dataset:

`https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/historical_automobile_sales.csv`

The application downloads the CSV at runtime, so the raw dataset is not duplicated in this repository.

## Repository structure
```text
automobile-sales-data-analysis/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── LINKEDIN_PROJECT.txt
├── notebooks/
│   └── automobile_sales_analysis.ipynb
└── src/
    └── analysis.py
```

## Run locally
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate

pip install -r requirements.txt
python app.py
```

Then open:

`http://127.0.0.1:8050`

## Key analyses
The notebook and Python analysis script include:
1. Average automobile sales by year
2. Recession vs. non-recession comparison by vehicle type
3. Advertising expenditure vs. automobile sales
4. GDP trends during recession and non-recession periods
5. Seasonality impact on sales
6. Consumer confidence vs. automobile sales during recessions
7. Advertising expenditure distribution
8. Unemployment rate vs. sales by vehicle type

## Business questions answered
- How strongly do automobile sales decline during recession periods?
- Which vehicle types are more resilient during recessions?
- Is higher advertising expenditure associated with higher sales?
- How do unemployment and consumer confidence relate to automobile demand?
- Which patterns are useful for planning marketing and inventory?

## LinkedIn-ready project description
See `LINKEDIN_PROJECT.txt` for a concise description you can paste into LinkedIn.

## Notes
This repository is structured as a portfolio project. Run the notebook and dashboard locally before publishing screenshots so your GitHub repository shows your own generated results.

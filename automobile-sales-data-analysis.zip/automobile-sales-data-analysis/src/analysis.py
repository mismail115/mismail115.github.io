import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

DATA_URL = r"https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/historical_automobile_sales.csv"

def load_data():
    return pd.read_csv(DATA_URL)

def yearly_sales(df):
    return df.groupby("Year")["Automobile_Sales"].mean()

def recession_vehicle_sales(df):
    rec = df[df["Recession"] == 1]
    return rec.groupby("Vehicle_Type")["Automobile_Sales"].mean().sort_values(ascending=False)

def plot_recession_vs_non_recession(df):
    summary = (
        df.groupby(["Recession", "Vehicle_Type"], as_index=False)["Automobile_Sales"]
        .mean()
    )
    plt.figure(figsize=(10, 6))
    sns.barplot(data=summary, x="Recession", y="Automobile_Sales", hue="Vehicle_Type")
    plt.title("Vehicle-Wise Sales During Recession and Non-Recession Periods")
    plt.xlabel("Economic Condition (0 = Non-Recession, 1 = Recession)")
    plt.ylabel("Average Automobile Sales")
    plt.tight_layout()
    plt.show()

def plot_advertising_vs_sales(df):
    non_rec = df[df["Recession"] == 0]
    plt.figure(figsize=(9, 6))
    sns.scatterplot(
        data=non_rec,
        x="Advertising_Expenditure",
        y="Automobile_Sales",
        hue="Vehicle_Type",
    )
    plt.title("Advertising Expenditure vs. Automobile Sales")
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    data = load_data()
    print("Dataset shape:", data.shape)
    print("\nAverage yearly sales:")
    print(yearly_sales(data).head())
    print("\nRecession vehicle performance:")
    print(recession_vehicle_sales(data))
    plot_recession_vs_non_recession(data)
    plot_advertising_vs_sales(data)

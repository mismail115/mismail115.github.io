import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

DATA_URL = r"https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/historical_automobile_sales.csv"

def load_data():
    df = pd.read_csv(DATA_URL)
    return df

df = load_data()

app = Dash(__name__)
app.title = "Automobile Sales Data Analysis"

years = sorted(df["Year"].dropna().astype(int).unique())

app.layout = html.Div(
    [
        html.H1("Automobile Sales Data Analysis Dashboard"),
        html.P(
            "Explore sales trends, recession effects, advertising spend, "
            "unemployment, and vehicle-type performance."
        ),
        html.Div(
            [
                html.Label("Analysis view"),
                dcc.Dropdown(
                    id="view",
                    options=[
                        {"label": "Recession Overview", "value": "recession"},
                        {"label": "Yearly Statistics", "value": "yearly"},
                    ],
                    value="recession",
                    clearable=False,
                ),
            ]
        ),
        html.Div(
            [
                html.Label("Year"),
                dcc.Dropdown(
                    id="year",
                    options=[{"label": str(y), "value": int(y)} for y in years],
                    value=int(years[-1]),
                    clearable=False,
                ),
            ],
            id="year-container",
        ),
        html.Div(
            [
                dcc.Graph(id="chart-1"),
                dcc.Graph(id="chart-2"),
                dcc.Graph(id="chart-3"),
                dcc.Graph(id="chart-4"),
            ]
        ),
    ],
    style={"maxWidth": "1200px", "margin": "0 auto", "padding": "24px"},
)

@app.callback(
    Output("year-container", "style"),
    Input("view", "value"),
)
def toggle_year(view):
    return {"display": "block"} if view == "yearly" else {"display": "none"}

@app.callback(
    Output("chart-1", "figure"),
    Output("chart-2", "figure"),
    Output("chart-3", "figure"),
    Output("chart-4", "figure"),
    Input("view", "value"),
    Input("year", "value"),
)
def update_charts(view, year):
    if view == "recession":
        rec = df[df["Recession"] == 1].copy()

        yearly = (
            rec.groupby("Year", as_index=False)["Automobile_Sales"]
            .mean()
        )
        fig1 = px.line(
            yearly,
            x="Year",
            y="Automobile_Sales",
            markers=True,
            title="Average Automobile Sales During Recession Periods",
        )

        vehicle = (
            rec.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"]
            .mean()
            .sort_values("Automobile_Sales", ascending=False)
        )
        fig2 = px.bar(
            vehicle,
            x="Vehicle_Type",
            y="Automobile_Sales",
            title="Average Sales by Vehicle Type During Recessions",
        )

        ad = (
            rec.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"]
            .sum()
        )
        fig3 = px.pie(
            ad,
            names="Vehicle_Type",
            values="Advertising_Expenditure",
            title="Advertising Expenditure by Vehicle Type",
        )

        unemployment = (
            rec.groupby(["unemployment_rate", "Vehicle_Type"], as_index=False)[
                "Automobile_Sales"
            ]
            .mean()
        )
        fig4 = px.line(
            unemployment,
            x="unemployment_rate",
            y="Automobile_Sales",
            color="Vehicle_Type",
            markers=True,
            title="Unemployment Rate vs. Automobile Sales",
        )

    else:
        current = df[df["Year"] == year].copy()

        monthly = (
            current.groupby("Month", as_index=False)["Automobile_Sales"]
            .mean()
        )
        fig1 = px.line(
            monthly,
            x="Month",
            y="Automobile_Sales",
            markers=True,
            title=f"Monthly Automobile Sales — {year}",
        )

        vehicle = (
            current.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"]
            .mean()
        )
        fig2 = px.bar(
            vehicle,
            x="Vehicle_Type",
            y="Automobile_Sales",
            title=f"Average Sales by Vehicle Type — {year}",
        )

        ad = (
            current.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"]
            .sum()
        )
        fig3 = px.pie(
            ad,
            names="Vehicle_Type",
            values="Advertising_Expenditure",
            title=f"Advertising Expenditure Distribution — {year}",
        )

        fig4 = px.scatter(
            current,
            x="Consumer_Confidence",
            y="Automobile_Sales",
            color="Vehicle_Type",
            size="Seasonality_Weight",
            hover_data=["Month"],
            title=f"Consumer Confidence vs. Automobile Sales — {year}",
        )

    return fig1, fig2, fig3, fig4

if __name__ == "__main__":
    app.run(debug=True)
